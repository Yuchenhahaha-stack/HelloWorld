
/**
 * Write a description of class ArrayEx2 here.
 *
 * @author Yuchen W.
 * @version Version 4.2.2
 */
public class ArrayEx2
{
    // sort the given array
    // you can use one of the sort algorithms from the slides
    // change the array
    public static void sort(int[] arr) {
        int l=arr.length;
        for(int j=0; j<l; j++) {
            int mindex=j;
            for(int i=j; i<l; i++) {
                if(arr[i]<arr[mindex]) {
                    mindex=i;
                }
            }
            int tmp=arr[j];
            arr[j]=arr[mindex];
            arr[mindex]=tmp;
        }
        
    }

    // swap the int values at the two given indices
    public static void swap(int[] array, int index1, int index2) {
        int swap=array[index1];
        array[index1]=array[index2];
        array[index2]=swap;
    }


    //swap the integer values in the array at the specified indices after doubling them
    public static void swapAndDouble (int[] array, int index1, int index2){
        array[index1]*=2;
        if(index1 != index2) 
            array[index2]*=2;

        int swap=array[index1];
        array[index1]=array[index2];
        array[index2]=swap;
    }

    // swap the values at the two given indices and multiply each by n
    public static void swapAndMultiply(int[] array, int index1, int index2, int n) {
        int swap=array[index1];
        array[index1]=array[index2];
        array[index2]=swap;
        array[index1]*=n;
        array[index2]*=n;
    }

    // double all values of an array
    public static void doubleAll(int[] arr) {
        for(int i=0; i<arr.length; i++) 
            arr[i]*=2;

    }

    // multiply all the values of an array by n
    public static void multiplyAll(int[] arr, int n) {
        for(int i=0; i<arr.length; i++) 
            arr[i]*=n;
    }

    // return a NEW array that multiplies all of the values of the given array by n,
    // but does NOT CHANGE the original array
    public static int[] multiplyAll2(int[] arr, int n) {
        int[] newarr = new int[arr.length];
        for(int i=0; i<arr.length; i++) {
            newarr[i]=arr[i];
            newarr[i]*=n;
        }
        return newarr;
    }

    // count the number of values in arr that are above n
    public static int countAbove(int[] arr, int n) {
        int count=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i]>n) {
                count++;
            }
        }
        return count;
    }

    // count the number of values in arr that are positive and divisihble by n
    public static int countDivisible(int[] arr, int n) {
        int count=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i]>0 && arr[i]%n==0) 
                count++;
        }
        return count;
    }
    // return true if all the values are positive, and false otherwise
    public static boolean allPos(int[] arr) {
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<=0)
                return false;
        }
        return true;
    }

    // return true if all the values are at least n, and false otherwise
    public static boolean allAtLeastN(int[] arr, int n) {
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<n)
                return false;
        }
        return true;
    }

    // return true if all the values are at least n, and false otherwise
    // do this by calling the allAtLeastN function above
    public static boolean allPos2(int[] arr) {
        for(int i=0; i<arr.length; i++) {
            allAtLeastN(arr,0);
        }
        return true;
    }

    // count the number of values in arr that are at least lo and at most hi
    public static int countBetween(int[] arr, int lo, int hi) {
        int count=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<=hi &&arr[i]>=lo) 
                count++;
        }
        return count;
    }

    // return an array of size 3 containing the number of negative, zero, and positive values in the array, in that order
    public static int[] posNegZero(int[] arr) {
        int [] arr1=new int [3];
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<0)
                arr1[0]++;
            else if(arr[i]==0) 
                arr1[1]++;
            else
                arr1[2]++;
        }
        return arr1;
    }

    // return a new array containing only values that are less than max
    // HINT: You cannot easily remove elements from an array, so create a new array and copy over only the values
    // that are less than max
    public static int[] filterLess(int[] arr, int max) {
        int newlength=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<max)
                newlength++;
        }
        int [] arr1 = new int[newlength];
        int count=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i]<max) {
                arr1[count]=arr[i];
                count++;
            }
        }
        return arr1;
    }

    // return a NEW array that is a copy of the given array, but sorts all of the values
    // DO NOT CHANGE the original array
    // you can use one of the sort algorithms from the class slides
    // HINT: call the sort method that you already wrote on a copy of arr
    public static int[] sort2(int[] arr) { //How to call a function or method?
        int [] newarr = new int [arr.length];
        for(int i=0; i<newarr.length; i++) 
            newarr[i]=arr[i];
        sort(newarr);
        return newarr;
    }

    // return the number of strings in arr that are longer than len
    public static int countLonger(String[] arr, int len) {
        int count=0;
        for(int i=0; i<arr.length; i++) {
            if(arr[i].length()>len)
                count++;
        }
        return count;
    }

    // return the length of the longest String in arr
    public static int maxLen(String[] arr) {
        int l=arr.length;
        for(int i=0; i<l-1; i++) {
            if(arr[i].length()>arr[i+1].length()) {
               String swap=arr[i];
               arr[i]=arr[i+1];
               arr[i+1]=swap;
            }
        }
        return arr[l-1].length();
}
    // return the length of the longest String in arr
    // some of the string values may be null. Treat those as of length zero
    public static int maxLen2(String[] arr) {//Why when I called the function that has 
        for(int i=0; i<arr.length; i++) {    // a return statement, I have to write the 
            if(arr[i]==null)                 // return statement again?
                arr[i]=""; 
    }
    maxLen(arr); 
    return arr[arr.length-1].length();
}
    // return the sum of all of the values in the the given array
    public static int sum(int[] arr) {
        int sum = 0;
        for(int i=0; i<arr.length; i++) {
            sum+=arr[i];
        }
        return sum;
    }

    // return the largest sum of the values in each row of the given grid
    // the grid may not be square
    // For full credit: Use the sum() function you wrote above
    public static int maxRow(int[][] grid) {
        int [] newarr=new int [grid.length];
        for(int r=0; r<grid.length; r++) {
                newarr[r]=sum(grid[r]);
        }
        for(int i=0; i<newarr.length-1; i++) {
            if(newarr[i]>newarr[i+1]) {
                int swap=newarr[i];
                newarr[i]=newarr[i+1];
                newarr[i+1]=swap;
            }
        }
        return newarr[newarr.length-1];
    }

    // return the largest sum of the values in each row of the given grid
    // the grid may not be square
    // For full credit: Use the sum() function you wrote above
    public static int maxRowIndex(int[][] grid) {
        int [] indexarr=new int[grid.length];
         int [] newarr=new int [grid.length];
        for(int r=0; r<grid.length; r++) {
                newarr[r]=sum(grid[r]);
                indexarr[r]=r;
        }
        for(int i=0; i<newarr.length-1; i++) {
            if(newarr[i]>newarr[i+1]) {
                int swap=newarr[i];
                newarr[i]=newarr[i+1];
                newarr[i+1]=swap;
                int swap1=indexarr[i];
                indexarr[i]=indexarr[i+1];
                indexarr[i+1]=swap1; 
            }
        }
        return indexarr[indexarr.length-1];
    }
}
