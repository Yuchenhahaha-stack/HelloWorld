//Array Excercises;
public class ArrayExercises
{
    public static void main (String[] args){

        // use this space to test your code with method calls (we might 

        System.out.println("==============================================");
        searchAndRescue(new String[] {"Jaime", "David", "Rik", "Vera"}, "Vera");//answer is all but Vera
        searchAndRescue(new String[] {"Jaime", "David", "Rik", "Vera"}, "BillGates");//answer is all but Vera
        System.out.println("==============================================");
        System.out.println(nthLargest(new double[] {0,1,2,3,4,5,6,7,8,9,10},5));//answer=6
        System.out.println("----------------------------------------------");
        System.out.println(nthLargest(new double[] {40,-40,0},1));//answer=40
        System.out.println("==============================================");
        System.out.println(returnMedian(new int[] {3,4,2,1,5}));//answer=3
        System.out.println("----------------------------------------------");
        System.out.println(returnMedian(new int[] {0,-999,5}));//answer=0
        System.out.println("==============================================");
        reverseArray(new char[] {'y','l','f','e','r','i','f'});//answer=firefly
        System.out.println("==============================================");
        fakeFibonacciFirstN(10); //answer=1 1 5 13 41 121 365 1093 3281 9841
        System.out.println("==============================================");
        pivotClockwise(new char[][] {   {'A','B','C','D'},
                {'E','F','G','H'},
                {'H','I','J','K'}});//answer=   HEA
        //                                                              IFB 
        //                                                              JGC 
        //                                                              KHD
        System.out.println("==============================================");
        drawFlagX(new char [20][80]);
        System.out.println("==============================================");
        drawFlagXOXO(new char [20][40]);
        System.out.println("==============================================");

    }

    //take in a 2D array and rotate it clockwise, just like rotating a Picture full of pixels
    //first row becomes last column, second row becomes second to last column, etc.
    public static void pivotClockwise (char [][] letters){//assume all rows have same number of cols
        int height=letters.length;
        int width=letters[0].length;
        char[][] newchar=new char[width][height];
        for(int r=0; r<height; r++) {
            for(int c=0; c<width; c++) {
                newchar[c][height-r-1]=letters[r][c];
            }
        }

        printPattern(newchar);
    }

    //turn the array backwards so that first character is last, last is first ("abcde" --> "edcba")
    public static void reverseArray (char[] characters){
        int l=characters.length;
        char swap='a';
        for(int i=0; i<l/2; i++) {//Why can't I declare a variable in the for loop?
            swap = characters[i];
            characters[i]=characters[l-1-i];
            characters[l-1-i]=swap;
        }
        printRow(characters);
    }

    //create and return an array with the first n fake-Fibonacci numbers
    //similar to regular Fibonacci but fib(n)=fib(n-1)*2 + fib(n-2)*3
    //so each value is a sum of the previous two values, but with some multiplications
    // if 4th value is 13 and 5th value is 41, then 6th value is 41*2+13*3=121
    public static int[] fakeFibonacciFirstN (int n){//n > 2   (prev1*2+prev2*3)
        int [] fibonacci = new int [n];
        fibonacci[0]=1;
        fibonacci[1]=1;
        for(int i=2; i<fibonacci.length; i++) {
            fibonacci[i]=fibonacci[i-1]*2+fibonacci[i-2]*3;
        }
        // put your code here!
        // the 1st and 2nd values are both 1, so put those at the front of your array at [0] and [1]
        printRow(fibonacci);
        return(fibonacci);//REPLACE THIS to return YOUR new array
    }

    //find the provided String person (assume at most one present) and remove them from the String array
    //return the array of only remaining people
    // NOTE: This is no easy way to remove something from an array. Make a new array and copy over only
    // the things
    public static String[] searchAndRescue (String[] people, String person){
        String [] newpeople = new String [people.length-1];
        int count=0;
        for(int i=0; i<people.length; i++) {
            if(people[i].equals (person) ) {
                for(int c=0; c<i; c++) {
                    newpeople[c]=people[c];
                }
                for(int d=i; d<newpeople.length; d++) {
                    newpeople[d]=people[d+1];
                }
                count++;
            }
        }
        if(count>0){
            printRow(newpeople);
            return newpeople; 
        }
        else{
            printRow(people);
            return people;
        } 
    }

    //return the n-th largest value in the array
    public static double nthLargest(double[] numbers, int n){
        printRow(numbers);
        for(int j=0; j<numbers.length; j++) {
            int mindex=j;
            for(int i=j; i<numbers.length; i++) {
                if(numbers[i]<numbers[mindex]) 
                    mindex=i;
            }
            double swap=numbers[j];
            numbers[j]=numbers[mindex];
            numbers[mindex]=swap;
        }
        double value=numbers[numbers.length-n];
        double [] useless=new double [] {numbers[numbers.length-n]};
        printRow(useless);
        return value; //REPLACE THIS WITH THE N-TH LARGEST VALUE
    }

    //return the median value (i.e. the value at the middle point between lowest and highest values)
    //a sort or a partial sort would help
    //you can assume the length of the array will always be odd so there will always be a unique median
    public static int returnMedian(int [] numbers){
        printRow(numbers);
        for(int j=0; j<numbers.length; j++) {
            int mindex=j;
            for(int i=j; i<numbers.length; i++) {
                if(numbers[i]<numbers[mindex]) 
                    mindex=i;
            }
            int swap=numbers[j];
            numbers[j]=numbers[mindex];
            numbers[mindex]=swap;
        }

        int value = numbers[(numbers.length-1)/2];
        int [] useless2 = new int [] {value};
        printRow(useless2);
        return value;//REPLACE THIS WITH YOUR FOUND MEDIAN VALUE

    }
    //---------------------------------------------------------------------------
    /* draw a bumerang full of X chars (requires a 2D array [a][4a])
    X
    X X
    X X X
    X X X X
    X X X X X
    X X X X X X
    X X X X X X X
    X X X X X X X X
    X X X X X X X X X
    X X X X X X X X X
    X X X X X X X X
    X X X X X X X
    X X X X X X
    X X X X X
    X X X X
    X X X
    X X
    X

    HINT: fill in a 2D array with a triangle of 'X' chars 
    X
    X X X
    X X X X X
    X X X X X X X
    X X X X X X X X X
    X X X X X X X X X X X
    X X X X X X X X X X X X X
    X X X X X X X X X X X X X X X
    X X X X X X X X X X X X X X X X X
    X X X X X X X X X X X X X X X X X
    X X X X X X X X X X X X X X X
    X X X X X X X X X X X X X
    X X X X X X X X X X X
    X X X X X X X X X
    X X X X X X X
    X X X X X
    X X X
    X

    then fill over some of these X values with a smaller traingle full of ' ' blank chars    */
    public static void drawFlagX(char[][] flagPattern){
        flagPattern[0][0]='x';
        flagPattern[flagPattern.length-1][0]='x';
        for(int r=1; r<flagPattern.length/2; r++) {
            for(int c=0; c<2*r+1; c++) {
                flagPattern[r][c]='x';
                flagPattern[flagPattern.length-1-r][c]='x';
            }
        }
        for(int r=1;r<flagPattern.length/2; r++) {
            for(int c=0; c<r; c++) {
                flagPattern[r][c]=' ';
                flagPattern[flagPattern.length-1-r][c]=' ';
            }
        }

        printPattern(flagPattern);
    }

    /* draw and xoxo gossip girl flag within a 2D array [a][2a], 
    so we will only test this with 2D arrays with second dimmension being twice as large as the first dimmension;
    i.e. twice the number of columns than rows

    X
    XOX
    XOXOX
    XOXOXOX
    XOXOXOXOX
    XOXOXOXOXOX
    XOXOXOXOXOXOX
    XOXOXOXOXOXOXOX
    XOXOXOXOXOXOXOXOX
    XOXOXOXOXOXOXOXOXOX
    XOXOXOXOXOXOXOXOXOX
    XOXOXOXOXOXOXOXOX
    XOXOXOXOXOXOXOX
    XOXOXOXOXOXOX
    XOXOXOXOXOX
    XOXOXOXOX
    XOXOXOX
    XOXOX
    XOX
    X

     */
    public static void drawFlagXOXO(char[][] flagPattern){
       flagPattern[0][0]='x';
       flagPattern[flagPattern.length-1][0]='x';
      for(int r=1; r<flagPattern.length/2; r++) {
            for(int c=0; c<2*r+1; c++) {
                flagPattern[r][c]='x';
                flagPattern[flagPattern.length-1-r][c]='x';
            }
      }
      int count=1;
      for(int r=1; r<flagPattern.length/2; r++) {
         for(int c=1; c<2*r+1; c+=2) {
             flagPattern[r][c]='o';
             flagPattern[flagPattern.length-1-r][c]='o';
         }
      }
        printPattern(flagPattern);
    }

    // THERE IS NOTHING FOR YOU TO DO BELOW (THERE ARE CALLS TO THESE METHODS ABOVE TO CREATE SOME OUTPUTS)
    //----------------------- PRINTING TESTER METHODS -------------------
    // use these to test your code!! Choose which works for your needs
    //      method call: <nameoffunction>(variableName) <-- this variable datatype has to match the parameter type for the function
    // some of the functions below are overloaded: multiple functions with same name but different parameter types; this is legit and 
    //      Java will figure out which you meant to use by type of thing you pass in to the call

    //print a 2D char array
    public static void printPattern(char[][] pattern){
        for (int r=0; r<pattern.length; r++){
            printRow(pattern[r]);
        }
    }

    //print a 1D char array
    public static void printRow(char[] pattern){
        for (int c=0; c<pattern.length; c++)
            System.out.print(pattern[c]);
        System.out.println();
    }

    //print a 1D double array
    public static void printRow(int[] pattern){
        for (int c=0; c<pattern.length; c++)
            System.out.print(pattern[c]+" ");
        System.out.println();
    }

    //print a 1D double array
    public static void printRow(double[] pattern){
        for (int c=0; c<pattern.length; c++)
            System.out.print(pattern[c]+" ");
        System.out.println();
    }

    //print a 1D String array
    public static void printRow(String[] pattern){
        for (int c=0; c<pattern.length; c++)
            System.out.print(pattern[c]+" ");
        System.out.println();
    }
}
